/*
 Copyright (C) 2016 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 View controller for watching the device come and go
 */


@import UIKit;
@import ExternalAccessory;

@class EADSessionController;

@interface RootViewController : UITableViewController

@end
